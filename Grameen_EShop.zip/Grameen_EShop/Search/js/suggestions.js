let suggestions = [
    "Jamdani Saree",
    "Matir Jug",
    "Matir Bank",
    "Jute Bag",
    "Jute Shoe",
    "Jute Basket",
    "Jute Mattress",
    "Muslin Khadi ",
    "Panjabi"
    
    
];
