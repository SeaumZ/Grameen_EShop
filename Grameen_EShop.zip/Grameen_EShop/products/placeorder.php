<?=template_header('Place Order')?>

<head>
	<title>LOGIN</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
</head>
<body>
   
<h1>Your Order Has Been Placed</h1>
    <p><b> Thank you for ordering with us, we'll contact you by email with your order details.</b></p>

    
</div>
</body>
<?=template_footer()?>