-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2022 at 01:14 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grameenshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `desc` text NOT NULL,
  `price` decimal(7,2) NOT NULL,
  `rrp` decimal(7,2) NOT NULL DEFAULT 0.00,
  `quantity` int(11) NOT NULL,
  `img` text NOT NULL,
  `date_added` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `desc`, `price`, `rrp`, `quantity`, `img`, `date_added`) VALUES
(1, 'Jamdani Saree', 'Unique watch made with Jamdani.\r\n\r\n', '5000.00', '500.00', 10, 'Jamdani Saree.jpg', '2022-08-13 17:55:22'),
(2, 'Muslin Khadi', '', '4500.00', '1000.00', 34, 'Muslin Khadi.jpg', '2022-09-13 18:52:49'),
(3, 'Jute Mattress', '', '1500.00', '0.00', 23, 'Jute Mattress.jpg', '2019-03-13 18:47:56'),
(4, 'Jute Bag', '', '800.00', '200.00', 7, 'Jute Bag.jpg', '2019-03-13 17:42:04'),
(6, 'Jute Basket', 'Premium Basket', '1600.00', '200.00', 6, 'Jute Basket.jpg', '2022-08-24 00:03:55'),
(7, 'Jute Shoe', 'Built with high quality', '1999.00', '99.00', 9, 'Jute Shoe.jpg', '2022-08-24 00:05:18'),
(9, 'Matir Bank', '', '999.00', '99.00', 5, 'Matir Bank.jpg', '2022-08-24 00:11:04'),
(10, 'Panjabi', 'Khadi Product', '1999.00', '99.00', 6, 'Panjabi.jpg', '2022-08-24 00:12:17'),
(11, 'Tant Saree', 'Premium Quality', '2999.00', '99.00', 5, 'Tant sari.jpg', '2022-08-24 00:24:42'),
(12, 'Terra Cotta Art', '', '1999.00', '99.00', 6, 'Terra Cotta Art.jpg', '2022-08-24 00:27:49'),
(13, ' Flower Pots', '', '999.00', '99.00', 11, 'Terra Cotta Pots.jpg', '2022-08-24 00:29:12'),
(14, 'Terra Cotta Jar', '', '999.00', '99.00', 6, 'terra pot.jpg', '2022-08-24 00:30:20');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `txn_id` varchar(255) NOT NULL,
  `payment_amount` decimal(7,2) NOT NULL,
  `payment_status` varchar(30) NOT NULL,
  `item_id` varchar(255) NOT NULL,
  `item_quantity` varchar(255) NOT NULL,
  `item_mc_gross` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `payer_email` varchar(255) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL DEFAULT '',
  `address_street` varchar(255) NOT NULL,
  `address_city` varchar(255) NOT NULL,
  `address_state` varchar(255) NOT NULL,
  `address_zip` varchar(255) NOT NULL,
  `address_country` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `txn_id` (`txn_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
