<?php

require("connection.php");
session_start();

$msg ="";

if(isset($_POST['contact_data'])) {
    $UserName= $_POST['UserName'];
    $Email= $_POST['E-mail'];
    $Password= $_POST['Pasword'];
    $RepeatPassword= $_POST['RepeatPassword'];
    $firstName= $_POST['firstName'];
    $lastName= $_POST['lastName'];
    $Phone= $_POST['Phone'];
    $Street= $_POST['Street'];
    $City= $_POST['City'];
    $State= $_POST['State'];
    $Zipcode= $_POST['Zipcode'];
    $Country= $_POST['Country'];
    
    

    
        $contact_sql = "INSERT INTO contact(username,email,password,repeatpassword,fname, lname, phone,street,city,state,zipcode,country) 
        values('$UserName', '$Email', '$Password','$RepeatPassword', '$firstName', '$lastName', '$Phone', '$Street', '$City','$State','$Zipcode', '$Country')";




        if($conn->query($contact_sql)){
            $msg = "Message Sent";
        }
        else{
            die($conn->error);
        }
    
}




?>  
<!DOCTYPE html>
<html>
<head>
  <title>Registration</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
</head>
<body>
  <div class="container">
    <div class=" w-75 m-auto pb-5"> 
      <div class="text-center pt-8">
        <h3 class="mt-5 text-uppercase"> SignUp </h3>
        
        <div>
          <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
          <div class="form-row">
            <div class="form-group ">
              <label for="firstName">First Name</label>
              <input type="text" class="form-control" name="firstName"
              >
            </div>
            <div class="form-group ">
              <label for="lastName">Last Name</label>
              <input type="text" class="form-control" name="lastName"
              >
            </div>
            <div class="form-group ">
              <label for="E-mail">E-mail</label>
              <input type="email" class="form-control" name="E-mail" placeholder="Enter Valid E-mail">
              

            </div>
            <div class="form-group ">
              <label for="Password">Password</label>
              <input type="text" class="form-control" name="Password"
              >
            </div>
            <div class="form-group ">
              <label for="RepeatPassword">Repeat Password</label>
              <input type="text" class="form-control" name="RepeatPassword"
              >
            </div>
            
          </div>

<div class="form-group ">

<label for="Phone">Phone</label>
              <input type="text" class="form-control" name="Phone"
              >
</div>
<div class="form-group">
  <label for="Street"> Street </label>
  <textarea class="form-control" name="Street" ></textarea>
  
</div>
<div class="form-group ">
              <label for="City">City</label>
              <input type="text" class="form-control" name="City"
              >
            </div>
<div class="form-group ">
              <label for="State">State</label>
              <input type="text" class="form-control" name="State"
              >
            </div>

<div class="form-group ">
              <label for="Zipcode">Zipcode</label>
              <input type="text" class="form-control" name="Zipcode"
              >
            </div>

<div class="form-group ">
              <label for="Country">Country</label>
              <input type="text" class="form-control" name="country"
              >
            </div>
            

<button type="submit"  name="contact_data" class="btn btn-primary ">Sent</button>
<P>
    <?php echo $msg ?>
</P>
</form>
        </div>
      </div>
      
    </div>
    
  </div>
</body>