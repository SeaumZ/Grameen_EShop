-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2022 at 01:14 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `firstName` varchar(50) NOT NULL,
  `lastName` varchar(50) NOT NULL,
  `gender` enum('m','f','o') NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `number` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `firstName`, `lastName`, `gender`, `email`, `password`, `number`) VALUES
(1, 'seaum', 'zaman', 'm', 'seaumibnzaman@gmail.com', 'seaum', 1851701828),
(2, 'seaum', 'zaman', 'm', 'seaumibnzaman@gmail.com', 'seaum', 1851701828),
(3, 'seaum', 'zaman', 'o', 'be_seaum', 'be_seaum', 1851701828),
(4, 'seaum', 'zaman', 'f', 'be_seaum', 'be_seaum', 2147483647),
(5, 'seaum', 'zaman', 'm', 'be_seaum', 'be_seaum', 45748484),
(6, 'seaum', 'zaman', 'm', 'be_seaum', 'be_seaum', 45748484),
(7, 'seaum', 'zaman', 'm', 'seaumibnzaman@gmail.com', 'seaum', 2147483647),
(8, 'seaum', 'zaman', 'm', 'seaumibnzaman@gmail.com', '12345', 2147483647),
(9, 'seaum', 'zaman', 'm', 'be_seaum', 'sssssss', 2147483647),
(10, 'seaum', 'zaman', 'm', 'be_seaum', 'aaaaaaaaaaaaaaaaa', 2147483647),
(11, 'seaum', 'zaman', 'm', 'seaum@gmail.com', 'be_seaum', 1956276111),
(12, 'Nafia', 'Panna', 'f', 'nafia@gmail.com', 'be_seaum', 2147483647),
(13, 'Nafia', 'Panna', 'f', 'nafia@gmail.com', 'nafiaz', 1876543210),
(14, 'seaum', 'zaman', 'm', 'be_seaum', 'be_seaum', 2147483647),
(15, 'Al Shahoriar', 'saurov', 'm', 'alshahriar78@gmail.com', '1234', 1521507437),
(16, 'abcd', 'ef', 'm', 'asw@gmail.com', '123', 2147483647),
(17, 'North', 'South', 'm', 'nsu@gamil.com', '1234567', 16376217),
(18, 'Manir', 'Maya', 'm', 'manir@gmail.com', 'manir', 876876876),
(19, 'seaum', 'zaman', 'm', 'sss', 'sss', 5555);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
